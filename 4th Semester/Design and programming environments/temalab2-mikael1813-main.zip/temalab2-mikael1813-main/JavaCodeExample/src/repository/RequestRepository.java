package repository;

import model.ComputerRepairRequest;

public class RequestRepository extends AbstractRepository<ComputerRepairRequest, Integer>{
    public RequestRepository(){}
}
