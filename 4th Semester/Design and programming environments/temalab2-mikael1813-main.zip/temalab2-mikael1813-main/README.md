# starter-IntelliJ-Gradle

Starting with  IntelliJ and Gradle

Folosind IntelliJ, descarcati acest repository pe calculatorul personal si executati urmatoarele: 

-creati un proiect Gradle

-folosind Gradle creati fisierul jar executabil asociat

-scrieti cel putin doua teste automate (folosind junit) si rulati-le folosind Gradle

-adaugati jurnalizare codului ales

-configurati instrumentul de jurnalizare folosit, pentru a afisa mesajele la consola si intr-un fisier text.

Incarcati solutia voastra pe GitHub Classroom.
