
Tren - v1 2021-05-14 11:54am
==============================

This dataset was exported via roboflow.ai on May 14, 2021 at 8:57 AM GMT

It includes 4 images.
Sina are annotated in YOLO v3 (Keras) format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

No image augmentation techniques were applied.


